TOM TAGALOG STAGE 4 REBUILD PACK
Version: Stage 4 Rebuild Pack v1.0
Date: 2026-05-09

Files included:
- system_prompt_tom_tagalog_tutor.txt
- teacher_profile_and_file_map.txt
- curriculum.txt
- core_patterns.txt
- verb_system.txt
- stage4_phrasebank.txt
- corpus_anchor_index.txt
- progress.txt
- tagalog_sentences.txt
- claude_review_brief.md

Notes:
- tagalog_sentences.txt is copied unchanged as the main corpus.
- The other files are replacement files for the Stage 4B rebuild.
- Start next live lesson at Module 52: Describing Things I.
