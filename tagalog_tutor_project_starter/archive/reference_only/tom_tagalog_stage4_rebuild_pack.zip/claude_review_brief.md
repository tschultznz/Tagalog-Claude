CLAUDE REVIEW BRIEF — TOM TAGALOG STAGE 4 REBUILD
Version: Stage 4 Rebuild Pack v1.0
Date: 2026-05-09

WHAT I WANT REVIEWED
Please review the attached Stage 4 rebuild for Tom’s Tagalog course.

Context:
Tom has existing Glossika-based familiarity. Earlier stages built basic structure, controlled vocabulary growth, and practical service/survival language. A recent service/repair module showed that Tom learns best with root-family hints, controlled pattern variation, choice-based half-dialogues, English intent hints after the prompts, and concise corrections after production.

Main goal:
Build a proper continuation of Stage 4 that expands practical everyday speech: descriptions, colors, food, shopping, home, people, weather, errands, transport, and daily recaps.

Please evaluate:
1. Is the module sequence sensible?
2. Are Modules 52–70 too broad, too narrow, or well-scoped?
3. Are the vocabulary clusters practical and high-frequency?
4. Does the format match Tom’s learning preferences?
5. Does the curriculum preserve grammar support without becoming too grammar-heavy?
6. Are the root-family maps accurate and useful enough?
7. Are there missing domains that Tom should add before Stage 5?
8. Are any add-on phrases unnatural or risky?
9. Should the Stage 4B modules be renumbered differently?
10. What should be the next 5 lessons in order?

Important constraints:
- No answer keys before Tom produces.
- Hints after drills are good.
- Root-family hints before new verb chunks are essential.
- Keep lessons production-first.
- Keep progress concise.
- Use corpus anchors first, then small high-frequency add-ons.
