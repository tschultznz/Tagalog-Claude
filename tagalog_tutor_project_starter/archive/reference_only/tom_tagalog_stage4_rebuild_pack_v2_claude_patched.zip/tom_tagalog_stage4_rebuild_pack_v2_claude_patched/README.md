TOM TAGALOG STAGE 4B REBUILD PACK v2 — CLAUDE PATCHED
Last updated: 2026-05-09

This pack replaces the previous Stage 4 rebuild pack.

Files included:
- system_prompt_tom_tagalog_tutor.txt
- teacher_profile_and_file_map.txt
- curriculum.txt
- core_patterns.txt
- verb_system.txt
- stage4_phrasebank.txt
- corpus_anchor_index.txt
- progress.txt
- claude_review_brief.md
- tagalog_sentences.txt

What changed from v1:
- added phrasebank no-answer-key rule
- added corpus naturalness rule
- added /scaffold escape hatch
- added listening micro rule
- added particles and po-register rule
- added date-tagged spaced repetition
- added Taglish-natural labeling
- added modules 53.5, 55.5, 56.5
- added root families: dala, dating, tira, alis
- folded/reserved Module 68 to avoid overlap
- updated progress to start Module 52

How to use:
Replace the old files with these.
Next live lesson should start with progress.txt and begin Module 52.
